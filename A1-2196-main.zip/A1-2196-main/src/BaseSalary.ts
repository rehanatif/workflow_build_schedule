export class BaseSalary {
    
}